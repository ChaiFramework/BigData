#!/usr/bin/env python3

import sys
import re

#Extract initial distance from distance.txt
def getDist(filepath):
    distance_list = []

    with open(filepath) as f:
        line = f.readline()
        while line:
            if line:
                try:
                    line = line.strip()
                    ind = line.split(': ')
                    distance_list.append([int(ind[0]), int(ind[1])])
                except:
                    break
            else:
                break
            line = f.readline()

    f.close()
    return distance_list
#Function to Emit Key Value pair
def emitKVP(distance):
    key =  [distance[i][0] for i in range(len(distance))]
    
    for line in sys.stdin:
        line = line.strip()
        ind = line.split(': ')
        if int(ind[0]) in key:
            pos = key.index(int(ind[0]))
            print("%s\t%s" %(ind[0], distance[pos][1]))

        linkedNd = []
        repl_str = re.compile('^\d+$')
        line = ind[1].split()
        for word in line:
                match = re.search(repl_str, word)
                if match:
                    linkedNd.append(int(match.group()))
        for link in linkedNd:
            pos = key.index(int(ind[0]))
            print("%s\t%s" %(link, distance[pos][1]+1 ))
            
if __name__ == "__main__":
    distance = getDist('distance.txt')
    emitKVP(distance)