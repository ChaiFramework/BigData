Student Name: Arjun Padmanabha Pillai
Student ID: s3887231

How to run:

- graph.txt is taken as input.
- Hadoop streaming jar file must be in the same folder on EMR master node.
- All python files must be in the same folder on EMR master node.
- run the shell script run.sh