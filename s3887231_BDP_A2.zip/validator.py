from mapper import getDist

def compare(distance1,distance2):
    var = 0
    for idx in range(len(distance1)):
        if distance1[idx][1]==distance2[idx][1]:
            continue
        else:
            var+=1

    if var == 0:
        print(1)
    else: 
        print(0)
            


if __name__ == "__main__":
    distance1 = getDist('distance.txt')
    distance2 = getDist('distance1.txt')
    
    compare(distance1,distance2)
