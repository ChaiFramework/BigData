#!/usr/bin/env python3
import sys

#Function to return shortest distance

def getDist():

    KVP = {}
    #Read input from stdin

    for line in sys.stdin:

        # parse the input of mapper.py
        k, v = line.split('\t')
        try:
            #Convert read input to int type 
            k = int(k)
            v = int(v)
        except ValueError:
            continue

        if k not in KVP.keys():
            KVP[k] = v
        else:
            if k < KVP[k]:
                KVP[k] = v

    for i in KVP:
        var = KVP[i]
        print(str(i)+': '+str(var))

if __name__ == "__main__":
    getDist()