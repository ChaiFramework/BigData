package streaming

import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}

object spStream {

  def main(args: Array[String]): Unit = {
    if (args.length < 2) {
      System.err.println("Usage: spStream <input_directory> <output_directory>")
      System.exit(1)
    }

    val output_path = args(1)

    val sparkConf = new SparkConf().setAppName("Assignment4WordCount").setMaster("local")

    val streamCont = new StreamingContext(sparkConf, Seconds(5))

    val lines = streamCont.textFileStream(args(0))
    val words = lines.flatMap(_.split(" "))
    val countW = words.map(x => (x, 1)).reduceByKey(_ + _)
    countW.print()

    //Task A
    val stringPat = "[a-zA-Z]+".r
    val taskAW = words.map(a => stringPat.findAllIn(a)).flatMap(a => a).map(x => (x, 1)).reduceByKey(_ + _)
    taskAW.print()
    taskAW.saveAsTextFiles(output_path+ "/taskA")


    //Task B
    val taskBW = lines.map(_.split(" ")).flatMap(_.combinations(2)).map(a=> (a.mkString(","),1)).
      filter(a=> a._1.length>2 && a._1.split(",")(0).length <5 && a._1.split(",")(1).length < 5 ).
      reduceByKey(_ + _)
    taskBW.saveAsTextFiles(output_path + "/taskB")


    streamCont.start()
    streamCont.awaitTermination()
  }
}