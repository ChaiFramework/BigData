Name: Arjun Padmanabha Pillai
Student ID: S3887231

How to run

- upload jar file to master node.
- use spark submit.
- streaming package.
- spStream is the object.
- hdfs:///user/arjunpillai1998 is the input.
- /output is the output.
- run the following code on hadoop.

spark-submit --class streaming.spStream --master yarn --deploy-mode client s3887231_BDP_A4.jar hdfs:///user/arjunpillai1998 /output