#!/usr/bin/env python3
import sys
s=0
int_count=[]
for line in sys.stdin:
    line = line.strip()
    taxiNum, count, kms = line.split('\t')
    try:
        kms=float(kms)
    except ValueError:
        continue

    clean= count.replace('[','')
    clean2=clean.replace(']','')
    clean3=clean2.replace(',','')

    tot = list(map(int, clean3.split(" ")))
    print('%s\t%s\t%s' % (taxiNum, sum(tot), kms/sum(tot)))