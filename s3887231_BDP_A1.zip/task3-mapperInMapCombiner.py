#!/usr/bin/env python3
import sys

counts={}
distance={}


for line in sys.stdin:
    line = line.strip()
    taxiNum, kms = line.split(', ')
    
    if taxiNum in distance.keys():
        distance[taxiNum] += int(kms)
        counts[taxiNum].append(1)
    else:
        distance[taxiNum] = int(kms)
        counts[taxiNum] = [1]

taxiID = list(counts.keys())
for i in range(len(taxiID)):
    print('%s\t%s\t%s' % (taxiID[i],  sum(counts[taxiID[i]]), distance[taxiID[i]]))
