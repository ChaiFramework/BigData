#!/usr/bin/env python3
import sys

counts={}
distance={}

for line in sys.stdin:
    line = line.strip()
    taxiNum, count, kms = line.split('\t')
    
    if taxiNum in distance.keys():
        distance[taxiNum] += float(kms)
        counts[taxiNum]+= 1
    else:
        distance[taxiNum] = float(kms)
        counts[taxiNum] = 1

taxiID = list(counts.keys())
for i in range(len(taxiID)):
    print('%s\t%s\t%s' % (taxiID[i], counts[taxiID[i]], distance[taxiID[i]]/counts[taxiID[i]]))