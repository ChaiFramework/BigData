#!/usr/bin/env python3
import sys
for line in sys.stdin:
    line = line.strip()
    taxiNum, kms= line.split(', ')
    print('%s\t%s\t%s' % (taxiNum, "1", kms))