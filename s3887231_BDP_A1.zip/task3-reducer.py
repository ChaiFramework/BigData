#!/usr/bin/env python3
import sys

counts={}
distance={}

for line in sys.stdin:
    line = line.strip()
    taxiNum, count, kms = line.split('\t')
    try:
        kms=float(kms)
        count=int(count)
    except ValueError:
        continue
    
    if taxiNum in distance.keys():
        distance[taxiNum] += float(kms)
        counts[taxiNum]+=1
    else:
        distance[taxiNum] = float(kms)
        counts[taxiNum] = int(count)

taxiID = list(counts.keys())
for i in range(len(taxiID)):
    print('%s\t%s\t%s' % (taxiID[i], counts[taxiID[i]], distance[taxiID[i]]/counts[taxiID[i]]))
