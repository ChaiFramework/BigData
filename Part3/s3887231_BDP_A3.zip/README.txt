Assignment 3
Student Name: Arjun Padmanabha Pillai
Student ID: S3887231

How to run:

1. put all data files into a folder called input.
2. run run.sh